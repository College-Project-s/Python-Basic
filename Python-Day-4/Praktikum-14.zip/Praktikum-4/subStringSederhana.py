text = "Python Programming"

#Mengambil substring dari indeks 0 hingga 6 (tidak termasuk 6) 
substring1 = text[0:6] # "Python"

# Mengambil substring dari indeks 7 hingga akhir 
substring2 = text[7:] # "Programming"

# Mengambil seluruh string dengan slicing 
substring3 = text[:] #"Python Programming"

print(substring1)
print(substring2) 
print(substring3)