# Parameter input
def Persegi(sisi):
    luas = sisi*sisi
    keliling = 4*sisi
    print('Luas : ',luas,"\n"'Keliling : ',keliling)

sisi = int(input('Masukan sisi : ')) 
Persegi(sisi)