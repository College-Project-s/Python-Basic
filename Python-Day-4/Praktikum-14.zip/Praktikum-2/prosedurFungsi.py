def HitungLuasPersegi():
    sisi = int(input('Masukan sisi : '))
    luas = sisi*sisi
    print('Luas persegi : ',luas)
    
    
bil= int(input('Masukan bilangan : '))
for i in range(1,bil+1):
        HitungLuasPersegi()